
import '../css/styles.css';
import 'bootstrap/dist/css/bootstrap.min.css';

import "./apiMeal";
import "./print"
import "./receta"
import "./searchByArea"
import  "./searchByCategory"